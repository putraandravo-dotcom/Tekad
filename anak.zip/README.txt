MY PROGRESS — Android starter project

Tema: gelap + oranye. Berisi layar utama sederhana dan widget Android native.

PENTING:
- Ini adalah KODE SUMBER proyek, bukan APK siap pasang.
- Untuk menghasilkan APK, proyek harus dibangun menggunakan Android Studio atau lingkungan build Android yang kompatibel.
- Widget dapat ditambahkan dengan menekan lama layar utama Android > Widget > My Progress.
- Starter ini menghitung hari sejak tanggal mulai yang tersimpan. Tombol mulai ulang menetapkan tanggal hari ini.
- Ini prototipe awal; fitur pengingat, catatan pemicu, pengujian lintas perangkat, dan penyegaran tepat saat tengah malam perlu ditingkatkan.

Jika hanya menggunakan HP, membangun proyek Android native mungkin membutuhkan aplikasi/layanan build tambahan; tidak bisa dipasang langsung hanya dari ZIP ini.
