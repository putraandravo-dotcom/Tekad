package com.myprogress.streak

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val orange = Color.rgb(255, 138, 36)
    private val bg = Color.rgb(21, 21, 21)
    private val prefs by lazy { getSharedPreferences("progress", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun streak(): Int {
        val start = prefs.getString("start_date", today()) ?: today()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val startDate = sdf.parse(start) ?: Date()
        val now = sdf.parse(today()) ?: Date()
        return (((now.time - startDate.time) / 86400000L).toInt() + 1).coerceAtLeast(1)
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = "🔥 My Progress"
            textSize = 28f
            setTextColor(orange)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "${streak()} HARI"
            textSize = 42f
            setTextColor(orange)
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 12)
        })
        root.addView(TextView(this).apply {
            text = "Terus maju, satu hari demi satu hari!"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        root.addView(Button(this).apply {
            text = "Mulai streak dari hari ini"
            setOnClickListener {
                prefs.edit().putString("start_date", today()).apply()
                updateWidget()
                render()
            }
        })
        root.addView(Button(this).apply {
            text = "Aku terpeleset — mulai lagi"
            setOnClickListener {
                prefs.edit().putString("start_date", today()).apply()
                updateWidget()
                render()
            }
        })
        setContentView(root)
    }

    private fun updateWidget() {
        val manager = AppWidgetManager.getInstance(this)
        val ids = manager.getAppWidgetIds(ComponentName(this, StreakWidgetProvider::class.java))
        for (id in ids) StreakWidgetProvider.updateAppWidget(this, manager, id)
    }
}
