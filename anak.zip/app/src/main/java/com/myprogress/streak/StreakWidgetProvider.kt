package com.myprogress.streak

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StreakWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateAppWidget(context, manager, it) }
    }

    companion object {
        fun updateAppWidget(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences("progress", Context.MODE_PRIVATE)
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val today = sdf.format(Date())
            val start = prefs.getString("start_date", today) ?: today
            val startDate = sdf.parse(start) ?: Date()
            val now = sdf.parse(today) ?: Date()
            val days = (((now.time - startDate.time) / 86400000L).toInt() + 1).coerceAtLeast(1)
            val views = RemoteViews(context.packageName, R.layout.streak_widget)
            views.setTextViewText(R.id.widget_days, "🔥 $days HARI")
            views.setTextViewText(R.id.widget_message, "Satu hari demi satu hari 🧡")
            val intent = Intent(context, MainActivity::class.java)
            val pending = PendingIntent.getActivity(context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
